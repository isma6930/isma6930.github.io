from pygame import*
from math import*
from random import*


init()
mixer.init()## initialise différentes choses de pygame. Faut le mettre car ca marche mieux avec que sans
fenetre = display.set_mode((1446, 897), RESIZABLE)
pause=False
## Ouvre notre fenêtre pygame. il faudra peut être ouvrir une fenêtre avec des
## dimensions plus grande si votre image dépasse la taille 640*480
score1=0
score2=0
touche = mixer.Sound("touche.ogg")
perdre = mixer.Sound("perdre.ogg")
gagner = mixer.Sound("gagner.ogg")
but = mixer.Sound("but.ogg")
fond = image.load("fond2.png").convert() ## python charge votre image en mémoire, elle n’est pas
l=[-1,1]
l1=[-2,2]## encore à l’écran.
raquette = image.load("raquette13.jpg").convert_alpha()
police = font.SysFont("Russo_One",150,bold=False,italic=False)
police1 = font.SysFont("Russo_One",40,bold=True,italic=False)
police2 = font.SysFont("Arial_Narrow",37,bold=False,italic=False)
raquette2 = image.load("raquette13.jpg").convert_alpha()
balle = image.load("raquette10.png").convert_alpha()
for x in range (balle.get_size()[0]):
    for y in range (balle.get_size()[1]):
        (r,v,b,t)=balle.get_at((x,y))
        if r==255 and v==255 and b==255:
            balle.set_at((x,y),(r,v,b,0))
for x in range (raquette.get_size()[0]):
    for y in range (raquette.get_size()[1]):
        (r,v,b,t)=raquette.get_at((x,y))
        if r==255 and v==255 and b==255:
            raquette.set_at((x,y),(r,v,b,0))
for x in range (raquette2.get_size()[0]):
    for y in range (raquette2.get_size()[1]):
        (r,v,b,t)=raquette2.get_at((x,y))
        if r==255 and v==255 and b==255:
            raquette2.set_at((x,y),(r,v,b,0))
xp=1390 #coord raquette de l 'IA
yp=400  #coord raquette de l 'IA
xp1=20  #coord raquette du joueur
yp1=400 #coord raquette du joueur
deplacement_x=choice(l) #deplacement de la balle
deplacement_y=choice(l1) #deplacement de la balle
continuer=1 
xp2=400 #coords de la balle
yp2=400 #coords de la balle
deplacement_AI=0 #deplacement de la raquette du ai
while continuer==1:
    for evenements in event.get(): 
        if evenements.type == QUIT: 
            continuer = 0
    if evenements.type==MOUSEMOTION:  
        coord=mouse.get_pos() 
#deplacement avec la souris
        
        X_perso=coord[0]                        
        Y_perso=coord[1]
        if Y_perso >0 and Y_perso<fond.get_size()[1]-raquette2.get_size()[1]:  
            yp1=Y_perso
        elif Y_perso>fond.get_size()[1]-raquette2.get_size()[1]:
            Y_perso+=1



#deplacement avec le clavier
    
    keyb=key.get_pressed() 
    #if keyb[K_UP]:yp=yp-1.7 
    #if keyb[K_DOWN]:yp=yp+1.7
    if keyb[K_w] and yp1>0:
        yp1=yp1-1.7 
    if keyb[K_s] and yp1<fond.get_size()[1]-raquette2.get_size()[1]:
        yp1=yp1+1.7
#deplacement de la raquette de l'IA
    
    deplacement_AI=deplacement_y/2
    yp+=deplacement_AI
#deplacement de la balle
    
    xp2+=deplacement_x
    yp2+=deplacement_y
#collision avec le mur    
    if yp2>fond.get_size()[1]-balle.get_size()[1] or yp2<0:
        deplacement_y=-deplacement_y
#collision avec la raquette
    if Rect ((xp1,yp1),raquette.get_size()).colliderect (Rect((xp2,yp2),balle.get_size())):
        deplacement_x=randint(3,4)
        deplacement_y=randint(-3,3)
        balle = image.load("raquette10.png").convert_alpha()
        touche.play()
    if Rect ((xp,yp),raquette2.get_size()).colliderect (Rect((xp2,yp2),balle.get_size())):
        deplacement_x=randint(-4,-3)
        deplacement_y=randint(-3,3)
        balle = image.load("raquette12.png").convert_alpha()
        touche.play()
#le joueur marque un but
    if xp2>fond.get_size()[0]-balle.get_size()[0] :
        xp2=700
        yp2=400
        
        score1+=1
        deplacement_x=1
        deplacement_y=0
        yp1=400
        yp=400
        but.play()
#l'IA marque un but
        
    if xp2<0:
        xp2=700
        yp2=400
        
        score2+=1
        deplacement_x=-1
        deplacement_y=0
        yp=400
        yp1=400
        but.play()
    
    
        
    
   
    fenetre.blit(fond, (0,0)) # réaffichage du fond (pour effacer l’ancienne position du personnage)
    fenetre.blit(raquette,(xp,yp)) # affiche la raquette de l'IA
    fenetre.blit(raquette2,(xp1,yp1)) # affiche la raquette du joueur
    fenetre.blit(balle,(xp2,yp2)) # affichage de la balle
    text=police.render(str(score1),1,(randint(0,255),randint(0,255),randint(0,255))) # definir le score du joueur
    text1=police.render(str(score2),1,(randint(0,255),randint(0,255),randint(0,255))) # definir le score de l'IA
    victoire1=police1.render('le joueur 1 a gagne ! ',1,(255,0,255)) # affichage du gagnant joueur
    victoire2=police1.render("l'IA a gagne ! ",1,(255,0,255)) # affichage du gagnant IA
    rematch=police1.render('appuiyer sur r pour rejouer ou appuyer sur n pour quitter',1,(0,255,255)) # affichage du message pour recommencer
    fenetre.blit(text,(361,200)) # affichage du score du joueur
    fenetre.blit(text1,(1084,200)) # affichage du score de l'IA
# le joueur gagne

    if score1==5:
        deplacement_x=0
        deplacement_y=0
        fenetre.blit(victoire1,(625,450))
        fenetre.blit(rematch,(25,700))
        gagner.play()
        mixer.music.stop()
        if keyb[K_r]:
            score1=0
            score2=0
            xp2=400
            yp2=400
            deplacement_x=1
            deplacement_y=0
        elif keyb[K_n]:
            continuer=0
# l'IA gagne

    elif score2==5:
        
        deplacement_x=0
        deplacement_y=0
        fenetre.blit(victoire2,(625,450))
        perdre.play()
        fenetre.blit(rematch,(25,700))
        
        if keyb[K_r]:
            score1=0
            score2=0
            xp2=400
            yp2=400
            deplacement_x=1
            deplacement_y=0
        elif keyb[K_n]:
            continuer=0

    
        
        
    
    display.flip() 
quit()
